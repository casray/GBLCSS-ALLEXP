# Pattern Recognition submission package

This package keeps the Pattern Recognition review layout and the pagination optimizations from the preceding version.

## Main manuscript
- `main/main.tex`
- `main/main.pdf`
- 28 manuscript pages
- single-column CAS review layout retained
- double spacing retained
- page size, margins, and font size unchanged

## Final spacing adjustments
- Checked all display equations in `main.tex`.
- Removed unintended paragraph breaks immediately before Eq. (22), Eq. (23), and the unnumbered Brier-score formula in Section 4.3.1.
- The mathematical content, equation numbering, review line spacing, page geometry, and font size are unchanged.
- The manuscript remains 28 pages after recompilation.


## Page 14/15 pagination refinement
- The computational-cost paragraph is split at the complete sentence ending with the full-batch training cost.
- Page 14 now ends with that complete sentence.
- Page 15 begins with `At inference, the cost per node is` followed immediately by Eq. (23).
- No font size, margin, line spacing, equation spacing, or page geometry was changed.

## Acknowledgements
The requested wording is restored:

`This work was supported by the Yangtze River Delta Social Assistance Public Service Platform (B801065001FY050) and the National Natural Science Foundation of China (Nos. 62276136, 62206129, and 62375133).`

## Other pagination settings retained
- `microtype` for typographic line-breaking refinement.
- `placeins` with section barriers for float placement.
- Widow and orphan penalties set to 4600.
- No `\\enlargethispage` geometry override is used.

## Supplementary material
- `supplementary/supplementary.tex`
- `supplementary/supplementary.pdf`
- unchanged from the pagination-optimized package

## Highlights
- `highlights.docx`
- `highlights.txt`
