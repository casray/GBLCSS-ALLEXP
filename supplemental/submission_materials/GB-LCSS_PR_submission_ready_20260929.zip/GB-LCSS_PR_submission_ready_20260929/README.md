# GB-LCSS Pattern Recognition submission package

This package contains the cleaned review manuscript, standalone supplementary material, and a separate editable Highlights file.

## Submission files

- `main/main.pdf`: 29-page single-column, double-spaced review manuscript generated with `cas-sc` and the `review` option.
- `supplementary/supplementary.pdf`: 12-page standalone supplementary material, kept single-spaced.
- `highlights.docx`: separate editable Highlights file.
- `highlights.txt`: plain-text copy of the same Highlights.

## Source changes made in this revision

1. Removed the Highlights environment from `main/main.tex`, so the main manuscript now starts directly with the title page.
2. Suppressed the empty CAS `ORCID(s):` footnote until verified ORCID identifiers are available.
3. Kept all supplementary appendices in the separate supplementary file and replaced its full article-style front matter with a compact standalone supplement heading.
4. Adjusted the Acknowledgements paragraph locally to avoid visible line overflow without changing the funding information.
5. Preserved the existing scientific text, equations, tables, figures, references, and supplementary appendix numbering.

## Build

Compile `main/main.tex` from the `main/` directory. The supplied `main.bbl` is included, so the current PDF can be reproduced with repeated LaTeX runs; if BibTeX is available, the usual LaTeX -> BibTeX -> LaTeX -> LaTeX workflow can also be used.

Compile `supplementary/supplementary.tex` separately from the `supplementary/` directory. It has no external bibliography.

## Note before submission

The manuscript source still contains comments reminding the authors to add verified ORCID identifiers, a CRediT authorship contribution statement, a declaration of competing interest, and a data/code availability statement when applicable. These were not fabricated or filled automatically because they require author confirmation.
