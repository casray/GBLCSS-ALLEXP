# Pattern Recognition submission package - pagination optimized

This package keeps the Pattern Recognition review layout (single column, double spaced, page numbers) and optimizes page breaking without changing the paper's scientific content, font size, line spacing, page size, or margins.

## Main manuscript
- `main/main.tex`
- `main/main.pdf`
- 28 manuscript pages
- `review` option retained in `cas-sc`
- Highlights remain separate
- Supplementary material remains separate

### Pagination adjustments
- Added `microtype` for typographic line-breaking refinement.
- Added `placeins` with section barriers so floats from a later section do not move above the preceding section boundary.
- Relaxed the CAS class's absolute widow/orphan penalties from 10000 to 4600. This gives TeX enough freedom to avoid large unexplained page-bottom gaps while still penalizing isolated lines.
- Removed the previous `\enlargethispage{\baselineskip}` override so the normal page geometry is preserved.
- Split two short explanatory sentences into separate paragraphs at natural sentence boundaries to eliminate one-line carryovers at the tops of pages.

## Supplementary material
- `supplementary/supplementary.tex`
- `supplementary/supplementary.pdf`
- unchanged from the prior submission-ready package

## Highlights
- `highlights.docx`
- `highlights.txt`
